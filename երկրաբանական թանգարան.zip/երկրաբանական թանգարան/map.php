<?php
/**
 * 1. PROXY ՀԱՏՎԱԾ - Google Drive-ի նկարների համար
 */
if (isset($_GET['proxy_id'])) {
    $fileId = $_GET['proxy_id'];
    $url = "https://drive.google.com/thumbnail?id=" . $fileId . "&sz=w1000";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
    $data = curl_exec($ch);
    $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    curl_close($ch);
    if ($data) {
        header("Content-Type: " . $contentType);
        echo $data;
    }
    exit;
}

// 2. ՏՎՅԱԼՆԵՐԻ ԲԱԶԱՅԻ ՄԻԱՑՈՒՄ
$host = 'localhost';
$db   = 'armeniangeologicalmuseum'; 
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $pdo->query("SELECT * FROM museumdata");
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("<div style='color:red; padding:20px;'><b>Database Error:</b> " . $e->getMessage() . "</div>");
}
?>

<!DOCTYPE html>
<html lang="hy">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ինտերակտիվ Համակարգ | ՀՀ ԳԱԱ ԵԳԻ</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #1a237e;
            --accent-color: #d32f2f;
            --bg-color: #1e1e2d;
            --footer-bg: #1a1a27;
            --page-bg: #ffffff;
            --text-main: #333;
            --border-color: #eef0f2;
        }

        body { background-color: var(--bg-color); margin: 0; font-family: 'Segoe UI', Tahoma, sans-serif; display: flex; flex-direction: column; align-items: center; }
        
        .web-page { background-color: var(--page-bg); width: 100%; max-width: 1100px; padding: 20px 40px; box-shadow: 0 0 40px rgba(0,0,0,0.6); border-radius: 12px 12px 0 0; box-sizing: border-box; min-height: 80vh; }

        .main-header { display: flex; justify-content: space-between; align-items: center; padding-bottom: 20px; border-bottom: 2px solid var(--border-color); margin-bottom: 30px; gap: 15px; position: relative; }
        .logo-area { display: flex; align-items: center; gap: 20px; }
        .logo-placeholder { width: 70px; height: 70px; border-radius: 50%; overflow: hidden; flex-shrink: 0; background: #eee; }
        .logo-placeholder img { width: 100%; height: 100%; object-fit: contain; }
        .header-titles h1 { font-size: 20px; margin: 0 0 5px 0; color: var(--text-main); line-height: 1.2; }
        .header-titles h2 { font-size: 14px; margin: 0; color: #666; font-weight: normal; }

        .lang-btn { background: var(--primary-color); color: white; border: none; padding: 8px 15px; border-radius: 20px; cursor: pointer; font-weight: bold; font-size: 14px; transition: 0.3s; }
        .lang-btn:hover { background: var(--accent-color); }

        #search-box { width: 100%; padding: 12px; margin-bottom: 20px; border: 2px solid #3498db; border-radius: 5px; font-size: 16px; box-sizing: border-box; outline: none; }
        #map { height: 500px; width: 100%; border-radius: 12px; border: 1px solid #ccc; z-index: 1; }

        .system-info { margin: 30px 0; padding: 25px; background: #f8f9fa; border-radius: 15px; border-left: 5px solid var(--primary-color); }
        .system-info h3 { margin-top: 0; color: var(--primary-color); display: flex; align-items: center; gap: 10px; }
        .info-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-top: 15px; }
        .info-card { font-size: 14px; line-height: 1.5; color: #555; }
        .info-card i { color: var(--accent-color); font-size: 18px; margin-bottom: 10px; }

        .main-footer { background-color: var(--footer-bg); width: 100%; max-width: 1100px; color: #ccc; padding: 40px; border-radius: 0 0 12px 12px; display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 30px; box-sizing: border-box; }
        .footer-col h4 { color: #fff; margin-bottom: 20px; font-size: 16px; border-left: 3px solid var(--accent-color); padding-left: 10px; }
        .footer-col p { font-size: 14px; color: #fff; margin-bottom: 12px; display: flex; align-items: center; gap: 10px; }
        .social-icons { display: flex; gap: 15px; margin-top: 15px; }
        .social-icons a { font-size: 20px; color: #fff; transition: 0.3s; }
        .copyright { grid-column: 1 / -1; text-align: center; padding-top: 20px; border-top: 1px solid #333; font-size: 13px; color: #888; }

        @media (max-width: 850px) {
            .web-page { padding: 20px; }
            .main-header { flex-direction: column; text-align: center; }
            .logo-area { flex-direction: column; }
            .header-titles h1 { font-size: 18px; }
            #map { height: 350px; }
        }
    </style>
</head>
<body>

<div class="web-page">
    <header class="main-header">
        <div class="logo-area">
            <div class="logo-placeholder">
                <img src="թանգ.png" alt="Logo" onerror="this.src='https://via.placeholder.com/70?text=IGS'">
            </div>
            <div class="header-titles">
                <h1 data-i18n="main_title">ՀՀ ԳԱԱ ԵԳԻ Հ․Կարապետյանի անվան երկրաբանական թանգարան</h1>
                <h2 data-i18n="sub_title">Ցուցանմուշների ինտերակտիվ տեղեկատվական համակարգ</h2>
            </div>
        </div>
        <button class="lang-btn" onclick="toggleLanguage()">EN</button>
    </header>

    <section>
        <input type="text" id="search-box" data-i18n-placeholder="search_placeholder" placeholder="Որոնել..." autofocus>
        <div id="map"></div>
    </section>

    <section class="system-info">
        <h3 data-i18n="guide_title"><i class="fa-solid fa-microscope"></i> Համակարգի ուղեցույց</h3>
        <div class="info-grid">
            <div class="info-card">
                <i class="fa-solid fa-map-location-dot"></i>
                <p><b data-i18n="guide_1_head">Տեղորոշում:</b> <span data-i18n="guide_1_body">Քարտեզի վրա նշված յուրաքանչյուր կետ համապատասխանում է նմուշի բնական ծագման վայրին:</span></p>
            </div>
            <div class="info-card">
                <i class="fa-solid fa-database"></i>
                <p><b data-i18n="guide_2_head">Տվյալներ:</b> <span data-i18n="guide_2_body">Սեղմեք մարկերների վրա՝ նմուշի լուսանկարը և գիտական բնութագիրը տեսնելու համար:</span></p>
            </div>
            <div class="info-card">
                <i class="fa-solid fa-filter"></i>
                <p><b data-i18n="guide_3_head">Որոնում:</b> <span data-i18n="guide_3_body">Օգտագործեք վերևի դաշտը՝ ֆիլտրելու համար նմուշները ըստ ցանկացած պարամետրի:</span></p>
            </div>
        </div>
    </section>
</div>

<footer class="main-footer">
    <div class="footer-col">
        <h4 data-i18n="contact_title">Կապ մեզ հետ</h4>
        <p><i class="fa-solid fa-location-dot"></i> <span data-i18n="addr">Մարշալ Բաղրամյան պող․ 24/1</span></p>
        <p><i class="fa-solid fa-phone"></i> +374 10 58 29 36</p>
        <p><i class="fa-solid fa-envelope"></i> armgeomuseum@gmail.com</p>
    </div>
    <div class="footer-col">
        <h4 data-i18n="hours_title">Աշխատանքային ժամեր</h4>
        <p><i class="fa-solid fa-calendar-days"></i> <span data-i18n="work_days">Երկուշաբթի - Ուրբաթ</span></p>
        <p><i class="fa-solid fa-clock"></i> 11:00 - 17:00</p>
        <p><i class="fa-solid fa-door-closed"></i> <span data-i18n="closed">Շաբաթ, Կիրակի՝ Փակ</span></p>
    </div>
    <div class="footer-col">
        <h4 data-i18n="follow_title">Հետևեք մեզ</h4>
        <div class="social-icons">
            <a href="#"><i class="fa-brands fa-facebook"></i></a>
            <a href="#"><i class="fa-brands fa-instagram"></i></a>
            <a href="#"><i class="fa-brands fa-youtube"></i></a>
        </div>
    </div>
    <div class="copyright">
        &copy; 2026 <span data-i18n="copy_text">ՀՀ ԳԱԱ ԵԳԻ Երկրաբանական Թանգարան | Բոլոր իրավունքները պաշտպանված են:</span>
    </div>
</footer>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
    const rawData = <?php echo json_encode($locations, JSON_UNESCAPED_UNICODE); ?>;
    let currentLang = 'hy';

    const i18n = {
        hy: {
            main_title: "ՀՀ ԳԱԱ ԵԳԻ Հ․Կարապետյանի անվան երկրաբանական թանգարան",
            sub_title: "Ցուցանմուշների ինտերակտիվ տեղեկատվական համակարգ",
            search_placeholder: "Որոնել ըստ անվանման, տեսակի կամ հանքավայրի...",
            guide_title: "Համակարգի ուղեցույց",
            guide_1_head: "Տեղորոշում:",
            guide_1_body: "Քարտեզի վրա նշված յուրաքանչյուր կետ համապատասխանում է նմուշի բնական ծագման վայրին:",
            guide_2_head: "Տվյալներ:",
            guide_2_body: "Սեղմեք մարկերների վրա՝ նմուշի լուսանկարը և գիտական բնութագիրը տեսնելու համար:",
            guide_3_head: "Որոնում:",
            guide_3_body: "Օգտագործեք վերևի դաշտը՝ ֆիլտրելու համար նմուշները ըստ ցանկացած պարամետրի:",
            contact_title: "Կապ մեզ հետ",
            addr: "Մարշալ Բաղրամյան պող․ 24/1",
            hours_title: "Աշխատանքային ժամեր",
            work_days: "Երկուշաբթի - Ուրբաթ",
            closed: "Շաբաթ, Կիրակի՝ Փակ",
            follow_title: "Հետևեք մեզ",
            copy_text: "ՀՀ ԳԱԱ ԵԳԻ Երկրաբանական Թանգարան | Բոլոր իրավունքները պաշտպանված են:"
        },
        en: {
            main_title: "IGS NAS RA Geological Museum after H. Karapetyan",
            sub_title: "Interactive Information System of Exhibits",
            search_placeholder: "Search by name, type or locality...",
            guide_title: "System Guide",
            guide_1_head: "Location:",
            guide_1_body: "Each point on the map corresponds to the natural origin of the specimen.",
            guide_2_head: "Data:",
            guide_2_body: "Click on markers to see the specimen's photo and scientific description.",
            guide_3_head: "Search:",
            guide_3_body: "Use the field above to filter specimens by any parameter.",
            contact_title: "Contact Us",
            addr: "24/1 Marshal Baghramyan Ave, Yerevan",
            hours_title: "Opening Hours",
            work_days: "Monday - Friday",
            closed: "Saturday, Sunday: Closed",
            follow_title: "Follow Us",
            copy_text: "IGS NAS RA Geological Museum | All rights reserved."
        }
    };

    const map = L.map('map').setView([40.18, 44.51], 8);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
    let markersLayer = L.layerGroup().addTo(map);

    function displayPoints(data) {
        markersLayer.clearLayers();
        
        // Եթե տվյալներ չկան, դուրս գալ
        if (data.length === 0) return;

        let bounds = [];
        data.forEach((item) => {
            let lat = parseFloat(String(item['COL 3']).replace(',', '.'));
            let lon = parseFloat(String(item['COL 4']).replace(',', '.'));

            if (!isNaN(lat) && !isNaN(lon)) {
                let foundImage = "";
                let popupHtml = `<div style="width:220px; font-family: sans-serif;">`;
                popupHtml += `<b style="font-size:14px; color:var(--primary-color);">${item['COL 1'] || 'Specimen'}</b><hr style="margin:5px 0; border:0; border-top:1px solid #eee;">`;

                Object.keys(item).forEach(key => {
                    let val = String(item[key]).trim();
                    if (val && val !== "null" && val !== "") {
                        if (val.includes("drive.google.com") || val.match(/\.(jpg|jpeg|png|webp)$/i)) {
                            foundImage = val;
                        } else if (!['COL 1', 'COL 3', 'COL 4'].includes(key)) {
                            popupHtml += `<div class="info-row"><b>${key}:</b> ${val}</div>`;
                        }
                    }
                });

                if (foundImage) {
                    let finalSrc = foundImage.includes("drive.google.com") ? `?proxy_id=${foundImage.includes("/d/") ? foundImage.split('/d/')[1].split('/')[0] : foundImage.split('id=')[1].split('&')[0]}` : foundImage;
                    popupHtml += `<img src="${finalSrc}" loading="lazy" style="width:100%; margin-top:8px; border-radius:5px;">`;
                }

                popupHtml += `</div>`;
                const marker = L.marker([lat, lon]).bindPopup(popupHtml);
                markersLayer.addLayer(marker);
                bounds.push([lat, lon]);
            }
        });
        if (bounds.length > 0) map.fitBounds(bounds, { padding: [40, 40] });
    }

    function toggleLanguage() {
        currentLang = currentLang === 'hy' ? 'en' : 'hy';
        document.querySelector('.lang-btn').innerText = currentLang === 'hy' ? 'EN' : 'AM';
        
        document.querySelectorAll('[data-i18n]').forEach(el => {
            el.innerText = i18n[currentLang][el.getAttribute('data-i18n')];
        });
        
        const searchInput = document.getElementById('search-box');
        searchInput.placeholder = i18n[currentLang][searchInput.getAttribute('data-i18n-placeholder')];
        
        // Թարմացնել միայն եթե դաշտը դատարկ չէ
        if (searchInput.value.trim() !== "") {
            filterAndDisplay(searchInput.value);
        }
    }

    function filterAndDisplay(text) {
        const searchText = text.toLowerCase().trim();
        if (searchText === "") {
            markersLayer.clearLayers();
        } else {
            const filtered = rawData.filter(item => 
                Object.values(item).some(val => String(val).toLowerCase().includes(searchText))
            );
            displayPoints(filtered);
        }
    }

    document.getElementById('search-box').addEventListener('input', function(e) {
        filterAndDisplay(e.target.value);
    });

    // Հեռացված է սկզբնական displayPoints(rawData) կանչը, որպեսզի քարտեզը լինի դատարկ
</script>

</body>
</html>